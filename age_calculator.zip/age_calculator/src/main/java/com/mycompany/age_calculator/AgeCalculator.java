/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.mycompany.age_calculator;

import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.Instant;
import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.util.Date;
/**
 *
 * @author Kushagra
 */
@WebService(serviceName = "AgeCalculator")
public class AgeCalculator {

    /**
     * This is a sample web service operation
     
    @WebMethod(operationName = "hello")
    public String hello() {
        return "Hello !";
    } */
    
public static Date StringToDate(String dob) throws ParseException{
    SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
    Date date = formatter.parse(dob);
    System.out.println("Date object value: "+date);
    return date;
}
   @WebMethod(operationName = "calculate")
//   public String CalculateAge(@WebParam(name = "date") int dd,@WebParam(name = "month") int month,@WebParam(name = "year") int year) throws ParseException {​​​​
    public String calculate(@WebParam(name = "date") int dd, @WebParam(name = "month") int month, @WebParam(name = "year") int year) throws ParseException {
           

      String dob = dd+"-"+month+"-"+year;
      SimpleDateFormat formatter = new SimpleDateFormat("dd-MM-yyyy");
      Date date = formatter.parse(dob);
      //Converting obtained Date object to LocalDate object
      Instant instant = date.toInstant();
      ZonedDateTime zone = instant.atZone(ZoneId.systemDefault());
      LocalDate givenDate = zone.toLocalDate();
      //Calculating the difference between given date to current date.
      Period period = Period.between(givenDate, LocalDate.now());
      return "Your current age is: "+period.getYears()+" years "+period.getMonths()+" Months and "+period.getDays()+" days";
    }
    
}


